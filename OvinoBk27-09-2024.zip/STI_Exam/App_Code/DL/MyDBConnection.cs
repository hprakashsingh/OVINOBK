﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using DataAccess;


public abstract class MyDBConnection : DataAccess.GlobalConnection
{
    protected IDBManager dbManager = new DBManager(DataProvider.SqlServer);
    protected IDBManager dbManagerCRM = new DBManager(DataProvider.SqlServer);

    public MyDBConnection()
    {
        dbManager.ConnectionString = ConfigurationManager.ConnectionStrings["ELPConnectionString"].ToString();
    }
}
