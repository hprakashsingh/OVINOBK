﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;


namespace Bussinesslogic
{
    public class LoginModuleBL
    {
        LoginModuleDL obj = null;

        public LoginModuleBL()
        {
             obj = new LoginModuleDL();
        }
        public DataSet UserLoginDetailsBL(string UserName,string Password)
        {
            LoginModuleDL objCheckLogin = new LoginModuleDL();
            return objCheckLogin.UserLoginDetailsDL(UserName,Password);
        }
    }
}
