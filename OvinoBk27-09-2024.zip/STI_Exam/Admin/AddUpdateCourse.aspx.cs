﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddUpdateCourse : System.Web.UI.Page
{
    #region DeclareVariable
    StiExam obj = new StiExam();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            // Generate a new CSRF token and store it in ViewState
            string csrfToken = Guid.NewGuid().ToString();
            ViewState["CSRFToken"] = csrfToken;

            // Set the value of the hidden field to the CSRF token
            hndCsrfToken.Value = csrfToken;

            if (Session["UserId"] != null)
            {
                GetCourseDetails();
            }
        }
    }
    #region GetCourseDetails
    private void GetCourseDetails()
    {
        try
        {
            DataSet ds = obj.GetCourseDetails(Session["UserId"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdCourse.DataSource = ds.Tables[0];    
                GrdCourse.DataBind();
            }
            else
            {
                GrdCourse.DataSource = ds.Tables[0];
                GrdCourse.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region EditCourse
    protected void GrdCourse_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("EditCourse"))
            {
                hndCourseId.Value = e.CommandArgument.ToString();
                DataSet ds = obj.GetCourseDetails(Session["UserID"].ToString(), hndCourseId.Value);
                if (ds.Tables[1].Rows.Count > 0)
                {
                    txtCourseName.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["CourseName"].ToString());
                    txtCourseCode.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["CourseCode"].ToString());
                    txtStudentLimit.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["StudentLimit"].ToString());
                    ddlStatus.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Status"].ToString());
                    btnAddUpdateCourse.Text = "Update Course";
                    btnAddUpdateCourse.ToolTip = "Click here to update Course";
                    btnAddUpdateCourse.Focus();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormData
    private void ClearFormData()
    {
        try
        {
            hndCourseId.Value = "";
            hndCsrfToken.Value = "";
            txtCourseName.Text = "";
            txtCourseCode.Text = "";
            txtStudentLimit.Text = "";
            ddlStatus.SelectedValue = "Active";
            btnAddUpdateCourse.Text = "Add Course";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region Add/UpdateCourse
    protected void btnAddUpdateCourse_Click(object sender, EventArgs e)
    {
        int success = 0;
        try
        {
            if (ViewState["CSRFToken"] != null && ViewState["CSRFToken"].ToString() == hndCsrfToken.Value)
            {
                success = obj.AddUpdateCourse(Session["UserId"].ToString(), hndCourseId.Value, HttpUtility.HtmlEncode(txtCourseName.Text.Trim()),
                    HttpUtility.HtmlEncode(txtCourseCode.Text.Trim()), HttpUtility.HtmlEncode(txtStudentLimit.Text.Trim()), ddlStatus.SelectedValue);
                if (success > 0)
                {
                    GetCourseDetails();
                    if (hndCourseId.Value != "")
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Course is successfully updated.', 'Success');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Course is successfully added.', 'Success');", true);
                    }
                    ClearFormData();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Course is not added. Please try again later!', 'Error');", true);
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Invalid CSRF token. Please try again later!', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetPage
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormData();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region CheckCourseName
    protected void txtCourseName_TextChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.CheckCourseAndCode(Session["UserID"].ToString(), HttpUtility.HtmlEncode(txtCourseName.Text.Trim()));
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtCourseName.Text = "";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Course Name already exist.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region CheckCourseCode
    protected void txtCourseCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.CheckCourseAndCode(Session["UserID"].ToString(), HttpUtility.HtmlEncode(txtCourseCode.Text.Trim()));
            if (ds.Tables[1].Rows.Count > 0)
            {
                txtCourseCode.Text = "";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Course Code already exist.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}