﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddMultipleCourse : System.Web.UI.Page
{
    #region DeclareVariable
    StiExam obj = new StiExam();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] != null)
        {
            GetCourseDetails();
        }
    }
    #region GetCourseDetails
    private void GetCourseDetails()
    {
        try
        {
            DataSet ds = obj.GetCourseDetails(Session["UserId"].ToString());
            if (ds.Tables[2].Rows.Count > 0)
            {
                ddlCourse.DataSource = ds.Tables[2];
                ddlCourse.DataTextField = "CourseName";
                ddlCourse.DataValueField = "CourseID";
                ddlCourse.DataBind();
                ddlCourse.Items.Insert(0, new ListItem("--Select Course--", ""));
            }
            if (ds.Tables[3].Rows.Count > 0)
            {
                ddlCandidateName.DataSource = ds.Tables[3];
                ddlCandidateName.DataTextField = "CandidateName";
                ddlCandidateName.DataValueField = "CandidateID";
                ddlCandidateName.DataBind();
                ddlCandidateName.Items.Insert(0, new ListItem("--Select Candidate--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    protected void btnAddUpdateCourse_Click(object sender, EventArgs e)
    {

    }

    protected void btnReset_Click(object sender, EventArgs e)
    {

    }
}