﻿function showToast(type, message, title) {
    switch (type) {
        case 'success':
            toastr.success(message, title);
            break;
        case 'error':
            toastr.error(message, title);
            break;
        case 'info':
            toastr.info(message, title);
            break;
        case 'warning':
            toastr.warning(message, title);
            break;
        default:
            console.log("Invalid toast type");
    }
}
function showToastAndRedirect(type, message, title, redirectUrl,Time) {
    toastr[type](message, title);
    setTimeout(function () {
        window.location.href = redirectUrl;
    }, Time); // Redirects after 5 seconds (adjust as needed)
}
function IsNumeric(evt) {
    // Get the key code of the pressed key
    var charCode = (evt.which) ? evt.which : event.keyCode;

    // Check if the key code corresponds to a numeric character (0-9) or special keys like backspace, delete, etc.
    if (charCode > 31 && charCode > 57) {
        // Prevent the default action of the key press event
        if (evt.preventDefault) {
            evt.preventDefault();
        } else {
            evt.returnValue = false;
        }
    }
}